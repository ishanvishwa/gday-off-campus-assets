/* G'day Mate Co — theme interactions (vanilla JS) */
(function () {
  'use strict';

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  /* ---- Mobile menu toggle ---- */
  function initMenu() {
    var burger = document.querySelector('.nav-burger');
    if (burger) {
      burger.addEventListener('click', function () {
        document.body.classList.toggle('menu-open');
      });
    }
    document.querySelectorAll('.mobile-menu a').forEach(function (a) {
      a.addEventListener('click', function () { document.body.classList.remove('menu-open'); });
    });
  }

  /* ---- Scroll reveal ---- */
  function initReveal() {
    ['.editorial', '.spotlight__inner', '.banner__inner', '.section__head',
     '.insta__head', '.cats > .container > .row-between'].forEach(function (sel) {
      document.querySelectorAll(sel).forEach(function (el) {
        if (!el.hasAttribute('data-reveal')) el.setAttribute('data-reveal', '');
      });
    });
    ['.grid', '.grid--3', '.grid--2', '.cats__row'].forEach(function (sel) {
      document.querySelectorAll(sel).forEach(function (group) {
        Array.prototype.forEach.call(group.children, function (child, i) {
          if (!child.hasAttribute('data-reveal')) {
            child.setAttribute('data-reveal', '');
            child.style.setProperty('--reveal-delay', i);
          }
        });
      });
    });

    var nodes = document.querySelectorAll('[data-reveal]');
    if (reduceMotion || !('IntersectionObserver' in window)) {
      nodes.forEach(function (el) { el.classList.add('is-visible'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { entry.target.classList.add('is-visible'); io.unobserve(entry.target); }
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.05 });
    nodes.forEach(function (el) { io.observe(el); });
  }

  /* ---- Magnetic buttons ---- */
  function initMagnetic() {
    if (!canHover || reduceMotion) return;
    document.querySelectorAll('.btn--primary, .btn--accent, .btn--ink, .link-pill, [data-magnetic]').forEach(function (el) {
      var rect, raf;
      el.addEventListener('mouseenter', function () { rect = el.getBoundingClientRect(); });
      el.addEventListener('mousemove', function (e) {
        if (!rect) rect = el.getBoundingClientRect();
        var x = (e.clientX - rect.left - rect.width / 2) * 0.22;
        var y = (e.clientY - rect.top - rect.height / 2) * 0.22 - 3;
        cancelAnimationFrame(raf);
        raf = requestAnimationFrame(function () { el.style.transform = 'translate3d(' + x + 'px,' + y + 'px,0)'; });
      }, { passive: true });
      el.addEventListener('mouseleave', function () { rect = null; cancelAnimationFrame(raf); el.style.transform = ''; });
    });
  }

  /* ---- Parallax tilt ---- */
  function initTilt() {
    if (!canHover || reduceMotion) return;
    var max = 5;
    document.querySelectorAll('.card, .cat, [data-tilt]').forEach(function (el) {
      var rect, raf;
      el.addEventListener('mouseenter', function () { rect = el.getBoundingClientRect(); el.style.transition = 'transform 0.12s ease-out'; });
      el.addEventListener('mousemove', function (e) {
        if (!rect) rect = el.getBoundingClientRect();
        var xp = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        var yp = ((e.clientY - rect.top) / rect.height) * 2 - 1;
        cancelAnimationFrame(raf);
        raf = requestAnimationFrame(function () {
          el.style.transform = 'perspective(900px) rotateX(' + (-yp * max) + 'deg) rotateY(' + (xp * max) + 'deg) translateZ(0)';
        });
      }, { passive: true });
      el.addEventListener('mouseleave', function () { rect = null; cancelAnimationFrame(raf); el.style.transition = 'transform 0.5s cubic-bezier(0.34,1.56,0.64,1)'; el.style.transform = ''; });
    });
  }

  /* ---- Spotlight border ---- */
  function initSpotlight() {
    if (!canHover || reduceMotion) return;
    document.querySelectorAll('.card, .cat').forEach(function (el) {
      el.addEventListener('mousemove', function (e) {
        var rect = el.getBoundingClientRect();
        el.style.setProperty('--mx', ((e.clientX - rect.left) / rect.width) * 100 + '%');
        el.style.setProperty('--my', ((e.clientY - rect.top) / rect.height) * 100 + '%');
      }, { passive: true });
    });
  }

  /* ---- Quantity steppers (cart + product) ---- */
  function initQty() {
    document.querySelectorAll('[data-qty]').forEach(function (wrap) {
      var input = wrap.querySelector('input');
      if (!input) return;
      wrap.querySelectorAll('button').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var step = btn.dataset.dir === 'up' ? 1 : -1;
          var val = Math.max(parseInt(input.min || '1', 10), (parseInt(input.value, 10) || 1) + step);
          input.value = val;
          input.dispatchEvent(new Event('change', { bubbles: true }));
        });
      });
    });
  }

  /* ---- Product: variant selection (option pills + price) ---- */
  function initVariants() {
    var root = document.querySelector('[data-product-variants]');
    if (!root) return;
    var variants;
    try { variants = JSON.parse(root.querySelector('[data-variant-json]').textContent); } catch (e) { return; }
    var priceEl = document.querySelector('[data-price]');
    var atcBtn = document.querySelector('[data-atc]');
    var idInput = root.querySelector('[name="id"]');

    function selected() {
      var opts = [];
      root.querySelectorAll('[data-option-index]').forEach(function (group) {
        var on = group.querySelector('.is-on');
        opts[parseInt(group.dataset.optionIndex, 10)] = on ? on.dataset.value : null;
      });
      return opts;
    }
    function update() {
      var opts = selected();
      var match = variants.find(function (v) { return v.options.every(function (o, i) { return o === opts[i]; }); });
      if (!match) return;
      if (idInput) idInput.value = match.id;
      if (priceEl) priceEl.textContent = match.price;
      if (atcBtn) {
        atcBtn.disabled = !match.available;
        atcBtn.querySelector('[data-atc-label]').textContent = match.available ? atcBtn.dataset.labelAdd : atcBtn.dataset.labelSold;
      }
    }
    root.querySelectorAll('[data-option-index] [data-value]').forEach(function (pill) {
      pill.addEventListener('click', function () {
        if (pill.classList.contains('is-off')) return;
        pill.parentElement.querySelectorAll('[data-value]').forEach(function (p) { p.classList.remove('is-on'); });
        pill.classList.add('is-on');
        update();
      });
    });
    update();
  }

  /* ---- PDP accordion ---- */
  function initAccordion() {
    document.querySelectorAll('.acc__head').forEach(function (h) {
      h.addEventListener('click', function () { h.parentElement.classList.toggle('is-open'); });
    });
  }

  function boot() {
    initMenu();
    initReveal();
    initMagnetic();
    initTilt();
    initSpotlight();
    initQty();
    initVariants();
    initAccordion();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
