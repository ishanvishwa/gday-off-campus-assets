# G'day Mate Co — Shopify Theme

A purpose-built, claymorphism streetwear theme converted from the static G'day Mate Co site.
Online Store 2.0 — JSON templates, editable sections, real Liquid objects.

## Structure

```
assets/        base.css (full design system + section styles), interactions.js
config/        settings_schema.json (brand colors + fonts), settings_data.json
layout/        theme.liquid (shell; emits brand colors from settings)
locales/       en.default.json
sections/      header/footer/announcement groups + home sections + main-* page sections
snippets/      product-card, mobile-menu, icon-search
templates/     index, product, collection, cart, page, search, list-collections, 404 (all JSON / OS 2.0)
```

## Home sections (drag/reorder/edit in the Theme Editor)
hero · trust-bar · editorial · featured-products · spotlight · categories (bento) · instagram · newsletter

## Wired to real Shopify data
- **Product** — media gallery, variant picker (Color → swatches, others → pills), AJAX-free add-to-cart, price/compare-at, accordion blocks, related collection.
- **Collection** — storefront filters, sort, 12/page pagination, product-card grid, empty state.
- **Cart** — line items, qty steppers, update + checkout (native `/cart` form), discounts, empty state.
- **Search / 404 / Collections list** — branded.

## Setup after install
1. **Menus:** create/point `Main menu` (Home, Shop, About…) and `Footer` menu — header/footer read these.
2. **Featured products:** Theme Editor → Home → *Featured products* → pick a collection.
3. **Spotlight:** pick the featured product.
4. **Categories:** assign a collection to each bento tile (drives the live style count).
5. **Brand colors / fonts:** Theme Editor → Theme settings → Brand colors / Typography.

## Local dev
```bash
shopify theme dev --store your-store.myshopify.com
shopify theme check
shopify theme push --unpublished   # uploads as a new, unpublished theme
```

Fonts load from Google Fonts (Fredoka + Nunito). Motion respects `prefers-reduced-motion`.
